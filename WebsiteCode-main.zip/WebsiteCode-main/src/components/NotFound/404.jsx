import React, { Component } from 'react'

class NotFound extends Component {
	render() {
		return (
			<div className="row">
				<div className="col-12">
					<img src="https://i.stack.imgur.com/6M513.png" />
				</div>
			</div>
		)
	}
}

export default NotFound
